// Popup JavaScript for Samantha AI Extension
class SamanthaAIPopup {
  constructor() {
    this.isListening = false;
    this.recognition = null;
    this.transcripts = [];
    this.init();
  }

  init() {
    console.log('Samantha AI Popup initializing...');
    this.bindEvents();
    this.loadSettings();
    this.updateStatus();
    this.initSpeechRecognition();
  }

  initSpeechRecognition() {
    try {
      console.log('Initializing speech recognition...');

      // Check if speech recognition is supported
      if (!('webkitSpeechRecognition' in window) && !('SpeechRecognition' in window)) {
        this.addTranscript('❌ Speech recognition not supported in this browser');
        return;
      }

      // Initialize speech recognition
      this.recognition = new (window.webkitSpeechRecognition || window.SpeechRecognition)();

      // Configure recognition
      this.recognition.continuous = false;
      this.recognition.interimResults = false;
      this.recognition.lang = 'en-US';
      this.recognition.maxAlternatives = 1;

      console.log('Speech recognition object created');

      // Event handlers with better error handling
      this.recognition.onstart = () => {
        console.log('Speech recognition started');
        this.isListening = true;
        this.updateUI();
        this.addTranscript('🎤 Listening started...');
      };

      this.recognition.onresult = (event) => {
        try {
          console.log('Speech recognition result received');
          const transcript = Array.from(event.results)
            .map(result => result[0].transcript)
            .join('');

          if (event.results[0].isFinal) {
            this.addTranscript(`🎯 Command: ${transcript}`);
            this.processCommand(transcript);
          }
        } catch (error) {
          console.error('Error processing speech result:', error);
          this.addTranscript('❌ Error processing speech result');
        }
      };

      this.recognition.onerror = (event) => {
        console.error('Speech recognition error:', event.error);
        this.isListening = false;
        this.updateUI();

        // Handle specific error types
        let errorMessage = 'Speech recognition error';
        switch (event.error) {
          case 'not-allowed':
            errorMessage = '❌ Microphone access denied. Please allow microphone access.';
            break;
          case 'no-speech':
            errorMessage = '❌ No speech detected. Please try again.';
            break;
          case 'audio-capture':
            errorMessage = '❌ Audio capture failed. Please check your microphone.';
            break;
          case 'network':
            errorMessage = '❌ Network error. Please check your internet connection.';
            break;
          case 'service-not-allowed':
            errorMessage = '❌ Speech recognition service not allowed.';
            break;
          default:
            errorMessage = `❌ Speech recognition error: ${event.error}`;
        }

        this.addTranscript(errorMessage);
      };

      this.recognition.onend = () => {
        console.log('Speech recognition ended');
        this.isListening = false;
        this.updateUI();
        this.addTranscript('🛑 Listening stopped');
      };

      this.addTranscript('✅ Speech recognition initialized successfully');

    } catch (error) {
      console.error('Error initializing speech recognition:', error);
      this.addTranscript('❌ Failed to initialize speech recognition');
    }
  }

  bindEvents() {
    console.log('Binding events...');

    // Voice orb click
    const voiceOrb = document.getElementById('voiceOrb');
    if (voiceOrb) {
      console.log('Voice orb found, adding click listener');
      voiceOrb.addEventListener('click', () => {
        console.log('Voice orb clicked');
        this.toggleListening();
      });
    } else {
      console.error('Voice orb not found!');
    }

    // Control buttons
    const startBtn = document.getElementById('startBtn');
    if (startBtn) {
      console.log('Start button found, adding click listener');
      startBtn.addEventListener('click', () => {
        console.log('Start button clicked');
        this.startListening();
      });
    } else {
      console.error('Start button not found!');
    }

    const stopBtn = document.getElementById('stopBtn');
    if (stopBtn) {
      console.log('Stop button found, adding click listener');
      stopBtn.addEventListener('click', () => {
        console.log('Stop button clicked');
        this.stopListening();
      });
    } else {
      console.error('Stop button not found!');
    }

    const clearBtn = document.getElementById('clearBtn');
    if (clearBtn) {
      console.log('Clear button found, adding click listener');
      clearBtn.addEventListener('click', () => {
        console.log('Clear button clicked');
        this.clearTranscript();
      });
    } else {
      console.error('Clear button not found!');
    }

    // Settings toggles
    const autoStartToggle = document.getElementById('autoStartToggle');
    if (autoStartToggle) {
      console.log('Auto start toggle found, adding click listener');
      autoStartToggle.addEventListener('click', () => {
        console.log('Auto start toggle clicked');
        this.toggleSetting('autoStart');
      });
    } else {
      console.error('Auto start toggle not found!');
    }

    const voiceFeedbackToggle = document.getElementById('voiceFeedbackToggle');
    if (voiceFeedbackToggle) {
      console.log('Voice feedback toggle found, adding click listener');
      voiceFeedbackToggle.addEventListener('click', () => {
        console.log('Voice feedback toggle clicked');
        this.toggleSetting('voiceFeedback');
      });
    } else {
      console.error('Voice feedback toggle not found!');
    }

    // Listen for messages from background script
    chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
      console.log('Popup received message:', request);
      this.handleBackgroundMessage(request);
    });

    console.log('All events bound');
  }

  async startListening() {
    console.log('Starting listening...');
    try {
      if (!this.recognition) {
        this.addTranscript('❌ Speech recognition not available');
        return;
      }

      // Check if already listening
      if (this.isListening) {
        this.addTranscript('⚠️ Already listening');
        return;
      }

      // Start recognition
      this.recognition.start();
      console.log('Recognition started');

      try {
        await chrome.runtime.sendMessage({ action: 'startListening' });
        console.log('Background message sent');
      } catch (error) {
        console.error('Error sending background message:', error);
      }

    } catch (error) {
      console.error('Error starting listening:', error);
      this.addTranscript('❌ Error starting voice recognition');
    }
  }

  async stopListening() {
    console.log('Stopping listening...');
    try {
      if (this.recognition && this.isListening) {
        this.recognition.stop();
        console.log('Recognition stopped');

        try {
          await chrome.runtime.sendMessage({ action: 'stopListening' });
          console.log('Background stop message sent');
        } catch (error) {
          console.error('Error sending background stop message:', error);
        }
      }
    } catch (error) {
      console.error('Error stopping listening:', error);
      this.addTranscript('❌ Error stopping voice recognition');
    }
  }

  toggleListening() {
    console.log('Toggling listening...');
    if (this.isListening) {
      this.stopListening();
    } else {
      this.startListening();
    }
  }

  async processCommand(command) {
    console.log('Processing command:', command);
    try {
      const response = await chrome.runtime.sendMessage({
        action: 'processCommand',
        command: command
      });

      console.log('Command response:', response);

      if (response && response.success) {
        this.addTranscript(`✅ Executed: ${command}`);
        if (response.response && response.response.message) {
          this.speakResponse(response.response.message);
        }
      } else {
        this.addTranscript(`❌ Failed: ${response?.error || 'Unknown error'}`);
      }
    } catch (error) {
      console.error('Error processing command:', error);
      this.addTranscript(`❌ Error: ${error.message}`);
    }
  }

  speakResponse(text) {
    try {
      if ('speechSynthesis' in window) {
        const utterance = new SpeechSynthesisUtterance(text);
        speechSynthesis.speak(utterance);
      }
    } catch (error) {
      console.error('Error with speech synthesis:', error);
    }
  }

  updateUI() {
    console.log('Updating UI, isListening:', this.isListening);

    const voiceOrb = document.getElementById('voiceOrb');
    const status = document.getElementById('status');
    const startBtn = document.getElementById('startBtn');
    const stopBtn = document.getElementById('stopBtn');

    if (voiceOrb) {
      if (this.isListening) {
        voiceOrb.classList.add('listening');
      } else {
        voiceOrb.classList.remove('listening');
      }
    }

    if (status) {
      status.textContent = this.isListening ? 'Listening...' : 'Click to start listening';
    }

    if (startBtn) {
      startBtn.disabled = this.isListening;
    }

    if (stopBtn) {
      stopBtn.disabled = !this.isListening;
    }
  }

  addTranscript(text) {
    console.log('Adding transcript:', text);
    this.transcripts.push({
      text: text,
      timestamp: new Date().toLocaleTimeString()
    });
    this.updateTranscriptDisplay();
  }

  updateTranscriptDisplay() {
    const transcriptContainer = document.getElementById('transcript');
    if (transcriptContainer) {
      transcriptContainer.innerHTML = this.transcripts
        .map(entry => `<div class="transcript-entry">
          <span class="timestamp">${entry.timestamp}</span>
          <span class="text">${entry.text}</span>
        </div>`)
        .join('');
      transcriptContainer.scrollTop = transcriptContainer.scrollHeight;
    }
  }

  clearTranscript() {
    console.log('Clearing transcript');
    this.transcripts = [];
    this.updateTranscriptDisplay();
    try {
      chrome.runtime.sendMessage({ action: 'clearHistory' });
    } catch (error) {
      console.error('Error clearing history:', error);
    }
  }

  async loadSettings() {
    try {
      const result = await chrome.storage.local.get(['autoStart', 'voiceFeedback']);
      this.settings = {
        autoStart: result.autoStart || false,
        voiceFeedback: result.voiceFeedback || true
      };
      this.updateSettingsUI();
    } catch (error) {
      console.error('Error loading settings:', error);
    }
  }

  updateSettingsUI() {
    const autoStartToggle = document.getElementById('autoStartToggle');
    const voiceFeedbackToggle = document.getElementById('voiceFeedbackToggle');

    if (autoStartToggle) {
      autoStartToggle.checked = this.settings.autoStart;
    }

    if (voiceFeedbackToggle) {
      voiceFeedbackToggle.checked = this.settings.voiceFeedback;
    }
  }

  async toggleSetting(settingName) {
    try {
      this.settings[settingName] = !this.settings[settingName];
      await chrome.storage.local.set({ [settingName]: this.settings[settingName] });
      this.updateSettingsUI();
    } catch (error) {
      console.error('Error toggling setting:', error);
    }
  }

  async updateStatus() {
    try {
      const response = await chrome.runtime.sendMessage({ action: 'getStatus' });
      if (response && response.success) {
        this.isListening = response.isListening;
        this.updateUI();
      }
    } catch (error) {
      console.error('Error getting status:', error);
    }
  }

  handleBackgroundMessage(request) {
    console.log('Popup received message:', request);

    if (request.action === 'speakResponse' && this.settings.voiceFeedback) {
      this.speakResponse(request.text);
    }
  }
}

// Initialize the popup when DOM is loaded
console.log('DOM loaded, initializing Samantha AI Popup');
document.addEventListener('DOMContentLoaded', () => {
  console.log('DOMContentLoaded event fired');
  new SamanthaAIPopup();
});

// Fallback initialization
if (document.readyState === 'loading') {
  console.log('Document still loading, waiting for DOMContentLoaded');
} else {
  console.log('Document already loaded, initializing immediately');
  new SamanthaAIPopup();
}
